VISION KLUSSEN - GITHUB UPLOAD

1. Maak op GitHub een nieuwe repository aan
2. Upload de volledige inhoud van deze map
3. Zorg dat index.html in de hoofdmap staat
4. Zet GitHub Pages aan:
   - Settings
   - Pages
   - Deploy from branch
   - Branch: main
   - Folder: /root
5. Wacht 1 tot 3 minuten tot de site live staat

Bestanden:
- index.html
- assets/logo-blue.png
- assets/hero-right.png
- assets/service-bitumen.png
- assets/service-epdm.png
- assets/service-lekkage.png
- assets/service-renovatie.png
- assets/cta-bg.png
- assets/about-photo.png
